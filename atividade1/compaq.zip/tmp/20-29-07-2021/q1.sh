echo "se esforce como nunca e fracasse como sempre :)"
