mkdir /tmp/$(date +%H-%d-%m-%Y)
cp * /tmp/$(date +%H-%d-%m-%Y)
