x=$(echo "scale=1;($1+1)*($2-1)"|bc)
echo $x
