read -p "digite o número: " x
x=$(($x+134))
echo $x
