read -p 'diretorio 1: ' d1
read -p 'diretorio 2: ' d2
read -p 'diretorio 3: ' d3
read -p 'diretorio 4: ' d4
read -p 'diretorio 5: ' d5
echo "####d1####"
ls $d1
echo "####d2####"
ls $d2
echo "####d3####"
ls $d3
echo "####d3####"
ls $d4
echo "####d4####"
ls $d5
echo "####d5####"
